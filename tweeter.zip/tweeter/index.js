const express = require("express");
const path = require("path");
const session = require("express-session");
const mysql = require("mysql2");
const { resolve } = require("path/posix");
var cookieParser = require('cookie-parser');
const app = express();
const fileUpload = require("express-fileupload");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
var fs = require("fs");
const checktoke=require("./src/middleware/authchecktoken")
let JWT_SECRET="kdjfhgsdjk9pauwerekfcsdnafierofh"
const PORT = process.env.PORT || 7001;
let query;
const conn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "tweeter_group2",
});
app.use(fileUpload());
function queryexecutor(query) {
  return new Promise((resolve, reject) => {
    conn.query(query, (err, result) => {
      return resolve(result);
    });
  });
}
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "/public")));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "src/views"));
app.use(
  session({
    secret: "batch2tweeter",
    resave: true,
    saveUninitialized: true,
  })
);
app.listen(PORT, () => {
  console.log(`server is up on ${PORT}`);
});

app.get("/login" ,function (request, response) {
  response.render("login");
});





app.post("/auth", async function (request, response) {
  let username = request.body.username;
  let password = request.body.password;
  console.log("entered username=", username, "enterered password=", password);
  if (username && password) {
    query =
      "SELECT uid,password FROM login WHERE uname = '" +
      username+"'"; 
      console.log("login query=", query);
      let results = await queryexecutor(query);
      if(typeof results[0]!=='undefined'){
      if (bcrypt.compare(password, results[0].password)) {
      
      const token = jwt.sign(
        {
          id: results[0].uid,
          username: username
        },
        JWT_SECRET
      )
      console.log("generated tokemas=",token)
      return response
    .cookie("access_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
    })
    .status(200)
    .redirect('/home');
      
    }} else {
      response.send("Incorrect Username and/or Password!");
    }
    response.end();
  } else {
    response.send("Please enter Username and Password!");
    response.end();
  }
});
//added from here

app.get("/register", (req, res) => {
  res.render("register");
});

app.post("/register", async (req, res) => {
  let username = req.body.username;
  let sql11 =
    "SELECT count(*) as ct FROM `login` WHERE uname ='" + username + "'";
  console.log(sql11);
  let result=await queryexecutor(sql11);
    console.log(result);
    if (result[0].ct == 0) {
      let sampleFile;
      let uploadPath;
      sampleFile = req.files.sampleFile;
      console.log("sample's path", sampleFile);
      uploadPath =
      __dirname+"/public/image/profile/" +
        new Date().getTime() +
        "_" +
        sampleFile.name;

      let newname = new Date().getTime() + "_" + sampleFile.name;
      console.log("new name ", newname);
      console.log("Upload's Path", uploadPath);
      sampleFile.mv(uploadPath, function (err) {
        if (err) return res.status(500).send(err);
      });
     

      let fname = req.body.firstname;
      let lname = req.body.lastname;
      let addr = req.body.address;
      let contact = req.body.contact;
      let email = req.body.email;
      let dob = req.body.dob;
      let state = req.body.state;
      let city = req.body.city;

      let sql =
        "INSERT INTO `users`( `fname`, `lname`, `address`, `contact`, `dob`, `email`,`profile`,`city_id`, `state_id`, `isdeleted`) VALUES ('" +
        fname +
        "','" +
        lname +
        "','" +
        addr +
        "','" +
        contact +
        "','" +
        dob +
        "','" +
        email +
        "','" +
        newname +
        "','" +
        city +
        "','" +
        state +
        "','0')";
      console.log(sql);
      result=await queryexecutor(sql)
      console.log("result of the register query=",result,result.insertId);
      let username = req.body.username;
      let password = req.body.password;
      const hashedPassword = await bcrypt.hash(password, 10);
      console.log(hashedPassword);
      let sqllogin =
          "INSERT INTO `login`(`uid`,`uname`, `password`, `login_time`) VALUES ("+result.insertId+",'" +
        username +
        "','" +
        hashedPassword +
        "',(SELECT now())) ";
      console.log(sqllogin);
      result=await queryexecutor(sqllogin);
            res.redirect("/login");
    } else {
      console.log("username is already exists");
      res.send("Username Is Already Exists");
    }
 
});
app.get("/contact", function (req, res) {
  res.render("contact");
});
//tweet
app.get("/tweet",checktoke, function (req, res) {
  res.render("tweet");
});


app.get("/search",checktoke,async(req,res)=>{
  let sql="SELECT uname from login";
  userData=await queryexecutor( sql)
  res.render("search",{exp:userData});
  })

// app.post("/searchdatavalue",checktoke,async(req,res)=>{  
//   tabledata=req.body.uname || "";
//   sql="select login.uname,login.uid from login where uname like '%"+tabledata+"%'"
//   console.log("login user=",sql);
//   userData=await queryexecutor( sql)
//   console.log("matched user data=",userData)
//   for(let i=0;i<userData.length;i++)
//   {
//     query="select count(*) AS Followers from follows  where destination_uid='"+userData[i].uid+"' ";''
//     console.log(query);
//     let followers=await queryexecutor(query);
//     let Followerscount=followers[0].Followers
//     console.log(Followerscount);
//     query="select count(*) AS Following from follows  where source_uid ='"+userData[i].uid+"' ";''
//     console.log(query);
//     Following=await queryexecutor(query);
//     let Followingcount=Following[0].Following
//     console.log(Followingcount) 
//     let exp=[];
//     sql2="SELECT count(*) as ct FROM follows where source_uid='"+req.userid+"' and destination_uid='"+userData[i].Following+"' and isfollow=1;";
//     userData1=await queryexecutor( sql2)
//     let ct=userData1[0].ct;
//     exp[i]={
//     ct:ct,
//     uname:userData[i].uname,
//     Followers:Followerscount,
//     Following:Followingcount,
//     id:userData[i].uid}
//     console.log(exp);
//     res.render("search",{exp:exp});
//   }
  // sql1="SELECT login.uname,count(*) AS Followers,follows.destination_uid AS Following,users.id from login LEFT JOIN follows ON login.uid=follows.source_uid LEFT JOIN users ON users.id=follows.destination_uid WHERE login.uname LIKE '%" +tabledata+"%' AND follows.source_uid=login.uid " ;
  // console.log("krupa............");
  // console.log(sql1);
  //
  // userData=await queryexecutor( sql1)
  
  // //console.log(userData);
  // for(let i=0;i<userData.length;i++){
  
  // sql2="SELECT count(*) as ct FROM follows where source_uid='"+req.userid+"' and destination_uid='"+userData[i].Following+"' and isfollow=1;";
  // userData1=await queryexecutor( sql2)
  // let ct=userData1[0].ct;
  // exp[i]={
  // ct:ct,
  // uname:userData[i].uname,
  // Followers:userData[i].Followers,
  // Following:userData[i].Following,
  // id:userData[i].id}
  // //console.log(foloowing);
  // //console.log(foloowing.length)
  // console.log(exp);
  // res.render("search",{exp:exp});
  // }
  //})
  
  // app.post("/searchdatavalue",checktoke,async(req,res)=>{

  //   tabledata=req.body.uname || "";
  //   sql1="SELECT login.uname, destination_uid,COUNT(source_uid) AS Followers FROM follows INNER JOIN login ON login.uid = follows.source_uid WHERE source_uid = "+req.userid+" AND login.uname LIKE '%"+tabledata+"%'";
  //   sql3="SELECT login.uname, destination_uid,COUNT(destination_uid) AS Following FROM follows INNER JOIN login ON login.uid = follows.destination_uid WHERE destination_uid = follows.destination_uid AND login.uname LIKE '%"+tabledata+"%'";
  //   console.log("krupa............");
  //   console.log(sql1,sql3);
  //   let exp=[];
  //   conn.query(sql1,function(err,userData){
  //   conn.query(sql3,function(err,userData2){
  //   //console.log(userData);
  //   for(let i=0;i<userData.length;i++){
    
  //   let ft=userData2[0].Following;
  //   sql2="SELECT count(*) as ct FROM follows where source_uid="+req.userid+" and destination_uid=follows.destination_uid and isfollow=1;";
  //   conn.query(sql2,function(err,userData1){
  //     console.log("destination id=",userData[i].destination_uid);
  //   let ct=userData1[0].ct;
  //   exp[i]={
  //   ct:ct,
  //   uname:userData[i].uname,
  //   Followers:userData[i].Followers,
  //   ft:ft,
  //   id:userData[i].destination_uid}
  //   //console.log(foloowing);
  //   //console.log(foloowing.length)
  //   console.log(exp);
  //   res.render("search",{exp:exp});
    
  //   })
    
  //   }
  //   })
  //   })
  //   })
    
    
    // app.post("/FollowData",checktoke,async(req,res)=>{
    // kk1=req.body;
    // console.log(kk1);
    // //if(Followers==1 && isfollow==0 && id==req.body.id){
    // sql1="INSERT INTO follows (source_uid,destination_uid,isfollow) values("+req.userid+",'"+kk1[0]+"',1)";
    // conn.query(sql1,function(err,userData){
    // if(err) throw err;
    // else{
    // console.log("done successfully");
    // }
    // })
    // //}
    // })
    
  
  // app.post("/FollowData",checktoke,async(req,res)=>{
  // kk1=req.body;
  // console.log(kk1);
  // console.log("logged user id=",req.userid)
  // //if(Followers==1 && isfollow==0 && id==req.body.id){
  // sql1="INSERT INTO follows (source_uid,destination_uid,isfollow) values('"+req.userid+"','"+kk1[0]+"',1)";
  // userData=await queryexecutor( sql1)
  

  console.log("done successfully");
  
 
  //})


  app.post("/edit", checktoke,async(req, res) => {
    try {
    
      let sampleFile;
      let uploadPath;
      sampleFile = req.files.sampleFile;
      console.log("sample's path", sampleFile);
      uploadPath =
      __dirname+"/public/image/profile/" +
        new Date().getTime() +
        "_" +
        sampleFile.name;
      let newname = new Date().getTime() + "_" + sampleFile.name;
      console.log("new name ", newname);
  
      console.log("Upload's Path", uploadPath);
      sampleFile.mv(uploadPath, function (err) {
        if (err) return res.status(500).send(err);
      });
      var e1 = `UPDATE users SET fname='${req.body.fname}',lname='${req.body.lname}',address='${req.body.address}',contact='${req.body.contact}',dob='${req.body.dob}',email='${req.body.email}',profile='${newname}' WHERE id='${req.body.id}'`;
      console.log("update query=",e1);

      let results=await queryexecutor(e1);
       res.redirect("/profile?id='"+req.body.id+"'");
    
    } catch (error) {
      console.log(error);
    }
  });

  app.post("/UnFollowData",checktoke,async(req,res)=>{
  kk1=req.body;
  console.log(kk1);
  
  sql1="UPDATE follows SET isfollow= 0 WHERE isfollow=1 AND source_uid='"+req.userid+"' AND destination_uid='"+kk1[0]+"'" ;
  userData=await queryexecutor( sql1)
  console.log("2nd done successfully");
  
 
  })

app.post("/addtweet",checktoke,async (req, res) => {
  var usertweet = req.body.tweet;
  let query = `INSERT INTO tweets (uid, tweet) VALUES (${req.userid},'${usertweet}')`;
  console.log("tweet insert query=",query);
  let result = await queryexecutor(query);
  res.redirect("/profile?id="+req.userid+"");
});
app.get("/search", checktoke,async (req, res) => {
  let query="SELECT uname from login"
  console.log(query);
  let userData = await queryexecutor(query);
  
  res.render("search", { exp: userData });
});
app.post("/like",checktoke, async (req, res) => {
  let data = req.body;
  console.log("entered into the like routes with tweet_id=", data.tweet_id);
  query =
    "select count(*) as like1 from likes where source_uid='"+req.userid+"' and tweet_id=" +
    data.tweet_id +
    "";
  console.log("select query=", query);
  count = await queryexecutor(query);
  console.log("already like count=", count[0].like1);
  if (count[0].like1 >= 1) {
    let id = "already";
    let data = { id: id };
    return res.send({ data });
  } else {
    query =
      "insert into likes(source_uid,tweet_id,likes) values('"+req.userid+"'," +
      data.tweet_id +
      ",1)";
    console.log("likes query=", query);
    likes = await queryexecutor(query);
    let id = "kasdjf";
    data = { id: id };
    return res.send({ data });
  }
});

app.get("/comments", async (req, res) => {
  console.log("received tweet_id=", req.query.tweet_id);
  query =
    "select (select uname from login where login.uid= comments.source_uid ) as uname,comments,comment_time from comments where tweet_id=" +
    req.query.tweet_id +
    "";
  console.log(query);
  let data = await queryexecutor(query);
  res.send({ data });
});

app.post("/comment/add",checktoke, async (req, res) => {
  console.log("tweeter id received", req.body.tweet_id);
  console.log("commented message=", req.body.comment);
  query =
    "insert into comments(source_uid,tweet_id,comments,isdeleted) value('"+req.userid+"'," +
    req.body.tweet_id +
    ",'" +
    req.body.comment +
    "',0)";
  console.log(query);
  await queryexecutor(query);
});

app.get("/editdata", async(req, res) => {
  try {
    var q1 = `SELECT id,fname,lname,address,contact,dob,email,profile,city_id,state_id,isdeleted,created_at,updated_at,profile FROM users WHERE id='${req.query.id}'`;
    console.log(q1);
    let results=await queryexecutor(q1);
      console.log(results);
      res.render("editdata", {
        any: results,
      });
    
  } catch (error) {
    console.log(error);
  }
});


// app.post("/edit", checktoke,async(req, res) => {
//   try {
//     console.log(req.body);
//     // ****
//     let sampleFile;
//     let uploadPath;

//     sampleFile = req.files.sampleFile;
//     console.log("sample's path", sampleFile);
//     uploadPath =
//     __dirname+"/public/image/profile/" +
//       new Date().getTime() +
//       "_" +
//       sampleFile.name;

//     let newname = new Date().getTime() + "_" + sampleFile.name;
//     console.log("new name ", newname);

//     console.log("Upload's Path", uploadPath);
//     sampleFile.mv(uploadPath, function (err) {
//       if (err) return res.status(500).send(err);
//     });

//     // ****
//     var e1 = `UPDATE users SET fname='${req.body.fname}',lname='${req.body.lname}',address='${req.body.address}',contact='${req.body.contact}',dob='${req.body.dob}',email='${req.body.email}',profile='${newname}' WHERE id='${req.body.id}'`;
//     console.log(req.params.id);
//     let results=await queryexecutor(results);
//       res.redirect("profile");
   
//   } catch (error) {
//     console.log(error);
//   }
// });



app.get("/profile",checktoke, async(req, res) => {
  console.log("received id=",req.query.id)
  try {
    var q1 = `SELECT id,fname,lname,address,contact,dob,email,profile,city_id,state_id,isdeleted FROM users WHERE id = ${req.query.id}`;
    var q2 =
      `select count(*) as followers from follows WHERE destination_uid=${req.query.id}`;
    var q3 = `select count(*) as following from follows WHERE source_uid=${req.query.id}`;
    var q4 = `select count(*) as tweets from tweets WHERE uid=${req.query.id}`;
    console.log("queries=",q1,q2,q3,q4);
    let results=await queryexecutor(q1)
    console.log(results);
    let result2=await queryexecutor(q2);  
    console.log(result2);
    let result3=await queryexecutor(q3);
    console.log(result3);
    let result4=await queryexecutor(q4);
    console.log(result4);

    //othere information of the user
    query="SELECT tid,tweet,tweet_time FROM tweets where uid="+req.query.id+""
    console.log("tweets query=",query);
    username="select uname from login where uid= "+req.query.id+"";
    console.log("username query=",username)
    username=await queryexecutor(username);
    username=username[0].uname
    tweets=await queryexecutor(query);
    let usertimline=[]
    console.log("tweets =",tweets)
    for (let i = 0; i < tweets.length; i++) {
      console.log(tweets[i].tid, tweets[i].tweet_time, tweets[i].tweet);
      query =
        "select count(*) as likes from likes where  tweet_id=" +
        tweets[i].tid +
        "";
      let like = await queryexecutor(query);
      console.log("total likes=", like[0].likes);
      usertimline.push({
        uname: username,
        tweets: tweets[i].tweet,
        tweet_time: tweets[i].tweet_time,
        tweet_id: tweets[i].tid,
        likes: like[0].likes,
      });
    }
    let edit=false;
    if(req.query.id==req.userid)
    {
       edit=true;
    }
    console.log("usertimline=",usertimline)
   res.render("profile", {
              any: results,
              any1: result2,
              any2: result3,
              any3: result4,
              usertimline:usertimline,
              id:req.query.id,
              edittable:edit
            });
      
  } catch (error) {
    console.log(error);
  }
});

app.get("/followerfollowing",checktoke,async(req,res)=>{
  //console.log(new String((req.query.status1)).valueOf() == "following")
  //console.log(req.params.type,req.query.type,((req.query.type).toString()=="following"));
  console.log(req.query)
  if((req.query.status1)=='following')
  {
    query="SELECT (destination_uid) as id,uname from login,follows where destination_uid=login.uid and source_uid="+req.query.id+"";
  }
  else if((req.query.status1)=='followers')
  {
    query="SELECT (source_uid) as id,uname from login,follows where source_uid=login.uid and destination_uid="+req.query.id+"";
  }
  console.log("query=",query)
  result=await queryexecutor(query)
  console.log("result",result)
  res.render('following_info',result);
})

app.get('/logout',(req,res)=>{
  res.clearCookie("access_token");
  res.render('login');
  res.end()
})

app.get("/home",checktoke, async (req, res) => {
  query = "select destination_uid from follows where source_uid='"+req.userid+"'";
  console.log("query to se  lect all followers are", query);
  let followers_id = await queryexecutor(query);
  console.log("length of the followerd", followers_id.length);
  let hometimeline = [];
  for (let i = 0; i < followers_id.length; i++) {
    for (key in followers_id[i]) {
      console.log(followers_id[i][key]);
      let uname =
        "select uname from login where uid=" +followers_id[i][key] + "";
      console.log("query=", uname);
      uname1 = await queryexecutor(uname);
      console.log(uname1.length, uname1[0].uname);
      query =
        "select tid,tweet_time,tweet from tweets where uid=" +
        followers_id[i][key] +
        "";
      tweets = await queryexecutor(query);
      console.log(tweets);
      console.log("all tweets of particular user");
      for (let j = 0; j < tweets.length; j++) {
        console.log(tweets[j].tid, tweets[j].tweet_time, tweets[j].tweet);
        query =
          "select count(*) as likes from likes where  tweet_id=" +
          tweets[j].tid +
          "";
        let like = await queryexecutor(query);
        console.log("total likes=", like[0].likes);
        hometimeline.push({
          identifier:followers_id[i][key],
          uname: uname1[0].uname,
          tweets: tweets[j].tweet,
          tweet_time: tweets[j].tweet_time,
          tweet_id: tweets[j].tid,
          likes: like[0].likes,
        });
      }
    }
  }
  console.log("all the hometimeline data=", hometimeline);
  res.render("hometimeline1", { hometimeline,id:req.userid });
});


app.get("/tweeter",checktoke, (req, res) => {
  res.render("tweet");
});
