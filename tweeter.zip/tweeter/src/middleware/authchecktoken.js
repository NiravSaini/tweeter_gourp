const jwt = require("jsonwebtoken");
const checktoke=async(req,res,next)=>{
  let JWT_SECRET="kdjfhgsdjk9pauwerekfcsdnafierofh"
  console.log("secret key from middleware=",JWT_SECRET)
  let token = req.cookies.access_token;
  console.log("from middelware toke=",token)
  console.log(!token);
  if (!token) {
    return res.sendStatus(403);
  }
  try {
    const data = jwt.verify(token,  JWT_SECRET);
    console.log("done..",data.id);
    req.userid=data.id;
    console.log(req.userid)
    console.log()
    next()
  } catch(err) {
    console.log(err.message)
    return res.sendStatus(403);
  }
}
module.exports=checktoke;